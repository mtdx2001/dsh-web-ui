import type { Context } from '@deepseek-ai/cordis';
import z from 'schemastery';
export interface BalanceAccount {
    id: string;
    label: string;
    source?: 'deepseek' | 'seventoken';
    provider?: 'deepseek' | 'seventoken';
    credentialName: string;
    order: number;
    enabled: boolean;
    currency: string;
    detailsMode?: 'balance' | 'token-usage';
}
export interface Config {
    accounts?: BalanceAccount[];
}
export declare const Config: z<Config>;
declare const ROUTE = "/api/dsh-balance-rows/accounts";
interface ProviderDirectoryEntry {
    provider: string;
    displayName: string;
    settingsNs: string;
    settingsPath: readonly string[];
}
interface ProviderServices {
    llm?: {
        listConfigurableProviders?: () => ProviderDirectoryEntry[];
    };
    settings?: {
        get?: (namespace: string) => unknown;
    };
}
export declare function discoverAccounts(services: ProviderServices): BalanceAccount[];
export declare const inject: string[];
export declare function apply(ctx: Context, config?: Config): void;
export { ROUTE };
