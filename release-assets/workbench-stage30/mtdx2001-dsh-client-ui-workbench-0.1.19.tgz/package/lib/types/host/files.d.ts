/**
 * Package-owned, read-only, workspace-confined file route for the Workbench
 * Files tab. Follows the git-status route conventions: loopback-only POST,
 * bounded bodies, bounded listings and reads, no shell. All path resolution is
 * structured (node:path + realpath); directory traversal, absolute paths, and
 * symlink escapes are rejected before any fs read.
 * @module dsh-workbench/host/files
 */
import type { Context } from '@deepseek-ai/cordis';
import type { WorkspaceGate } from './workspace-gate.ts';
export type FilesError = 'loopback-only' | 'method-not-allowed' | 'invalid-request' | 'invalid-root' | 'invalid-path' | 'path-escape' | 'not-found' | 'not-file' | 'not-directory' | 'workspace-unknown' | 'too-large' | 'binary' | 'timeout' | 'read-failed';
export interface WorkspaceEntry {
    readonly name: string;
    readonly kind: 'file' | 'directory';
}
export interface FilesListResult {
    readonly entries: WorkspaceEntry[];
    readonly truncated: boolean;
}
export interface FilesReadResult {
    readonly kind: 'text';
    readonly content: string;
    readonly truncated: boolean;
}
export type FilesOutcome<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error: FilesError;
};
/**
 * Resolve a client-supplied relative path inside a workspace root. Rejects
 * absolute paths and any `..` traversal that would leave the root. Pure;
 * performs no fs access.
 */
export declare function resolveWorkspacePath(root: string, rel: string): FilesOutcome<string>;
/** True when `target` equals or sits inside `base` (both already resolved). */
export declare function isContained(base: string, target: string): boolean;
/**
 * List one directory of the workspace: directories first, then files, both
 * name-sorted; capped at MAX_ENTRIES with a truncation flag.
 */
export declare function listWorkspaceDir(root: string, rel: string): Promise<FilesOutcome<FilesListResult>>;
/**
 * Read one workspace file as UTF-8 text. Files over MAX_FILE_BYTES are
 * rejected (never partially served); NUL bytes mark binary content.
 */
export declare function readWorkspaceFile(root: string, rel: string): Promise<FilesOutcome<FilesReadResult>>;
/** Register the read-only workspace files route; returns the disposer. */
export declare function registerFilesRoute(ctx: Context, gate: WorkspaceGate): () => void;
