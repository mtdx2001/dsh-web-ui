import type { Context } from '@deepseek-ai/cordis';
export type WorkspaceGateResult = {
    ok: true;
    canonical: string;
} | {
    ok: false;
    error: 'workspace-unknown';
};
export type WorkspaceGate = (root: string) => Promise<WorkspaceGateResult>;
/** Admit only canonical roots owned by the official workspace registry. */
export declare function createWorkspaceGate(ctx: Context): WorkspaceGate;
