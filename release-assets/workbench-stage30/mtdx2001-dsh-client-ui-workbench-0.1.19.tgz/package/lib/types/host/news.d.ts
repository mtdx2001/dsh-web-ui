import type { Context } from '@deepseek-ai/cordis';
export declare const NEWS_MAX_BYTES: number;
export declare const NEWS_TIMEOUT_MS = 10000;
export interface NewsSourceConfig {
    id: string;
    label: string;
    url: string;
}
interface ResolvedSource extends NewsSourceConfig {
    target: URL;
}
export declare function isPublicIpv4(address: string): boolean;
export declare function resolveNewsSources(configured: readonly NewsSourceConfig[]): ResolvedSource[];
export declare function registerNewsRoutes(ctx: Context, configured: readonly NewsSourceConfig[]): () => void;
export {};
