/**
 * Package-owned, loopback-only git change route behind the Changes tab. The
 * server re-derives every file's porcelain state itself and enforces the
 * write policy (staged rows unstage only; unstaged rows stage or discard;
 * untracked rows stage or single-file delete; unmerged rows refuse all
 * writes). Client-supplied state hints are never trusted. All git invocation
 * is execFile with `--` and `:(literal)` pathspecs — no shell. Untracked
 * delete realpaths the parent directory and removes the final component
 * without following it, so a symlink inside the repo loses the link, never
 * the target.
 * @module dsh-workbench/host/git-changes
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Context } from '@deepseek-ai/cordis';
import type { WorkspaceGate } from './workspace-gate.ts';
export type GitChangeOperation = 'diff' | 'stage' | 'unstage' | 'discard';
export interface GitChangeRequest {
    readonly root: string;
    readonly op: GitChangeOperation;
    readonly path: string;
}
export type GitFileState = 'staged' | 'unstaged' | 'staged-and-unstaged' | 'untracked' | 'unmerged' | 'clean' | 'missing';
export type GitChangeError = 'loopback-only' | 'method-not-allowed' | 'invalid-request' | 'invalid-path' | 'path-outside-root' | 'workspace-unknown' | 'not-repository' | 'not-found' | 'no-changes' | 'conflict-forbidden' | 'staged-discard-forbidden' | 'not-staged' | 'not-unstaged' | 'is-directory' | 'delete-failed' | 'timeout' | 'output-too-large' | 'git-unavailable' | 'git-failed' | 'internal-error';
export type GitChangeOutcome<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error: GitChangeError;
};
/** True when `candidate` equals or sits inside `root` (both separators normalized). */
export declare function isInsideRoot(root: string, candidate: string): boolean;
/**
 * Validate a client-supplied repo-relative path. Rejects empty, overlong,
 * NUL-containing, absolute, drive-letter, UNC, and `..` traversal input.
 * Pure; performs no fs access. Returns the `/`-normalized relative path.
 */
export declare function validateGitPath(repo: string, rel: string): GitChangeOutcome<string>;
/** Parse the first record of `git status --porcelain=v1 -z` output. Pure. */
export declare function parsePorcelainEntry(output: string): {
    x: string;
    y: string;
    path: string;
} | null;
/** Classify one porcelain XY pair into the policy state. Pure. */
export declare function classifyPorcelain(x: string, y: string): GitFileState;
/**
 * Server-side write policy. Returns the refusal error for a forbidden
 * operation, or undefined when allowed. `diff` is read-only and always
 * allowed. Pure.
 */
export declare function operationError(state: GitFileState, op: GitChangeOperation): GitChangeError | undefined;
/** Diff argv for a derived state; untracked files diff against /dev/null. Pure. */
export declare function diffArgsFor(state: GitFileState, path: string): string[];
/**
 * Execute one validated change request against the repository containing the
 * admitted workspace root. The state is re-derived per request and the write
 * policy is enforced server-side.
 */
export declare function executeGitChange(root: string, payload: {
    op: GitChangeOperation;
    path: string;
}): Promise<GitChangeOutcome<{
    content?: string;
    truncated?: boolean;
}>>;
/**
 * Build the route handler. The whole async body is wrapped so parse, gate, and
 * execution failures answer with structured JSON instead of hanging the
 * response or leaking an unhandled rejection.
 */
export declare function createGitChangesHandler(gate: WorkspaceGate): (req: IncomingMessage, res: ServerResponse) => void;
/** Register the git-changes route; returns the disposer. */
export declare function registerGitChangesRoute(ctx: Context, gate: WorkspaceGate): () => void;
