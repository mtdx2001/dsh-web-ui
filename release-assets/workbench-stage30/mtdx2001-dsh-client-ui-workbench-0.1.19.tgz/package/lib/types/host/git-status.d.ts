import type { Context } from '@deepseek-ai/cordis';
import type { WorkspaceGate } from './workspace-gate.ts';
interface ChangeRow {
    path: string;
    state: string;
    staged: boolean;
}
export declare function parseWorkbenchGitStatus(root: string, branch: string, output: string, prefix?: string): {
    root: string;
    branch: string;
    staged: ChangeRow[];
    unstaged: ChangeRow[];
    untracked: ChangeRow[];
};
export declare function readWorkbenchGitStatus(root: string): Promise<ReturnType<typeof parseWorkbenchGitStatus> | null>;
export declare function registerGitStatusRoute(ctx: Context, gate: WorkspaceGate): () => void;
export {};
