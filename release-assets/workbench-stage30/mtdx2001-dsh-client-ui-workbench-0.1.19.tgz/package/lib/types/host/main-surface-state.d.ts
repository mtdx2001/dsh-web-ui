import type { Context } from '@deepseek-ai/cordis';
import { type MainSurfacePersistedState } from '../core/main-surface-persisted.ts';
export declare const MAIN_SURFACE_STATE_ROUTE = "/dsh-workbench/main-surface-state";
export declare const MAIN_SURFACE_STATE_FILE = "dsh-workbench-main-surface.json";
export declare class MainSurfaceStateStore {
    readonly path: string;
    constructor(path?: string);
    read(): MainSurfacePersistedState;
    write(value: MainSurfacePersistedState): void;
}
export declare function registerMainSurfaceStateRoute(ctx: Context, store?: MainSurfaceStateStore): () => void;
