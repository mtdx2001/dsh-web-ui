import type { ReactNode } from 'react';
export interface WorkbenchRightPanelRegistration {
    readonly id: string;
    readonly order: number;
    readonly label: string | (() => string);
    readonly icon?: ReactNode | (() => ReactNode);
    readonly render: () => ReactNode;
    readonly source?: string;
    readonly builtin?: boolean;
    readonly availability?: () => {
        kind: 'available';
    } | {
        kind: 'unavailable';
        reason: string;
    };
}
export interface WorkbenchRightPanelSummary {
    /** Stable source-qualified identity used by preferences and active state. */
    readonly id: string;
    /** Contributor-local registration id. */
    readonly localId: string;
    readonly order: number;
    readonly label: string;
    readonly icon?: ReactNode;
    readonly source: string;
    readonly builtin: boolean;
    readonly availability: {
        kind: 'available';
    } | {
        kind: 'unavailable';
        reason: string;
    };
}
export interface WorkbenchRightPanelSnapshot {
    readonly revision: number;
    readonly panels: readonly WorkbenchRightPanelSummary[];
}
export declare class RightPanelRegistry {
    private readonly registrations;
    private readonly listeners;
    private snapshot;
    getSnapshot: () => WorkbenchRightPanelSnapshot;
    subscribe: (listener: () => void) => (() => void);
    register(registration: WorkbenchRightPanelRegistration): () => void;
    get(id: string): WorkbenchRightPanelRegistration | undefined;
    refresh(id?: string): void;
    clear(): void;
    private rebuild;
}
