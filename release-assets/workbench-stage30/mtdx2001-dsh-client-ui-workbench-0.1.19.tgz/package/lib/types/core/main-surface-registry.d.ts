import type { ReactNode } from 'react';
export interface MainSurfaceRenderActions {
    readonly close: () => void;
}
export interface WorkbenchMainSurfaceRegistration {
    readonly id: string;
    readonly order: number;
    readonly label: string | (() => string);
    readonly icon?: ReactNode | (() => ReactNode);
    readonly render: (actions: MainSurfaceRenderActions) => ReactNode;
    readonly source?: string;
    readonly availability?: () => {
        kind: 'available';
    } | {
        kind: 'unavailable';
        reason: string;
    };
}
export interface WorkbenchMainSurfaceSummary {
    readonly id: string;
    readonly localId: string;
    readonly order: number;
    readonly label: string;
    readonly icon?: ReactNode;
    readonly source: string;
    readonly availability: {
        kind: 'available';
    } | {
        kind: 'unavailable';
        reason: string;
    };
}
export interface MainSurfaceRegistrySnapshot {
    readonly revision: number;
    readonly modes: readonly WorkbenchMainSurfaceSummary[];
}
export declare class MainSurfaceRegistry {
    private readonly registrations;
    private readonly listeners;
    private snapshot;
    getSnapshot: () => MainSurfaceRegistrySnapshot;
    subscribe: (listener: () => void) => (() => void);
    register(registration: WorkbenchMainSurfaceRegistration): () => void;
    get(id: string): WorkbenchMainSurfaceRegistration | undefined;
    refresh(id?: string): void;
    clear(): void;
    private rebuild;
}
