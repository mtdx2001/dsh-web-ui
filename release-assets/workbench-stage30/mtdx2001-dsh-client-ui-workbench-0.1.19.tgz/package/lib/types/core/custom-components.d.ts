import type { ComponentRegion } from './component-preferences.ts';
export type CustomComponentKind = 'information' | 'text-panel';
export interface CustomComponentDefinition {
    readonly id: string;
    readonly kind: CustomComponentKind;
    readonly label: string;
    readonly region: ComponentRegion;
    readonly summary: string;
    readonly content: string;
    readonly createdAt: number;
}
export interface CustomComponentSnapshot {
    readonly revision: number;
    readonly components: readonly CustomComponentDefinition[];
}
export interface CreateCustomComponentInput {
    readonly kind: CustomComponentKind;
    readonly label: string;
    readonly region: ComponentRegion;
    readonly summary?: string;
    readonly content: string;
}
export declare const CUSTOM_COMPONENTS_KEY = "dsh-workbench-custom-components:v1:global";
export declare function parseCustomComponents(raw: string | null): readonly CustomComponentDefinition[];
export declare class CustomComponentService {
    private readonly storage;
    private components;
    private snapshot;
    private readonly listeners;
    constructor(storage?: Pick<Storage, 'getItem' | 'setItem'> | undefined);
    getSnapshot: () => CustomComponentSnapshot;
    subscribe: (listener: () => void) => (() => void);
    create(input: CreateCustomComponentInput): CustomComponentDefinition;
    remove(id: string): void;
    private publish;
}
