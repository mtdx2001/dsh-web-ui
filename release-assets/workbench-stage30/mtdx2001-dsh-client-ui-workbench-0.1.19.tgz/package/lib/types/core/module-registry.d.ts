export type WorkbenchModuleIcon = 'agent' | 'tasks' | 'knowledge' | 'experts' | 'news' | 'monitoring' | 'ssh' | 'settings' | 'extension';
export type WorkbenchModuleAvailability = {
    kind: 'available';
} | {
    kind: 'unavailable';
    reason: string;
};
export interface WorkbenchModuleRegistration {
    readonly id: string;
    readonly order: number;
    readonly label: string;
    readonly icon: WorkbenchModuleIcon;
    readonly availability?: () => WorkbenchModuleAvailability;
    readonly activate: () => void | Promise<void>;
    readonly deactivate?: () => void | Promise<void>;
}
export interface WorkbenchModuleSummary {
    readonly id: string;
    readonly order: number;
    readonly label: string;
    readonly icon: WorkbenchModuleIcon;
    readonly availability: WorkbenchModuleAvailability;
}
export interface ModuleRegistrySnapshot {
    readonly revision: number;
    readonly modules: readonly WorkbenchModuleSummary[];
}
export declare class ModuleRegistry {
    private readonly registrations;
    private readonly listeners;
    private snapshot;
    getSnapshot: () => ModuleRegistrySnapshot;
    subscribe: (listener: () => void) => (() => void);
    register(registration: WorkbenchModuleRegistration): () => void;
    get(id: string): WorkbenchModuleRegistration | undefined;
    refresh(id?: string): void;
    clear(): void;
    private rebuild;
}
