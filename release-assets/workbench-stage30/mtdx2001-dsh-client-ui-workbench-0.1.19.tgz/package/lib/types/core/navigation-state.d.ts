import type { ModuleRegistry } from './module-registry.ts';
export type NavigationPhase = 'idle' | 'activating' | 'active' | 'error';
export interface NavigationSnapshot {
    readonly phase: NavigationPhase;
    readonly activeId: string | undefined;
    readonly targetId: string | undefined;
    readonly error: string | undefined;
}
export type NavigationResult = {
    ok: true;
    activeId: string | undefined;
} | {
    ok: false;
    error: string;
    activeId: string | undefined;
};
export declare class NavigationController {
    private readonly registry;
    private readonly listeners;
    private readonly disposeRegistry;
    private snapshot;
    private queue;
    private disposal;
    private disposed;
    private transition;
    constructor(registry: ModuleRegistry);
    getSnapshot: () => NavigationSnapshot;
    subscribe: (listener: () => void) => (() => void);
    activate(id: string): Promise<NavigationResult>;
    deactivate(): Promise<NavigationResult>;
    /** Adopt state already changed by a legacy host entry without replaying its adapter. */
    adopt(id: string | undefined): Promise<NavigationResult>;
    settle(): Promise<void>;
    dispose(): Promise<void>;
    private enqueue;
    private activateNow;
    private transitionIsCurrent;
    private cancelTransition;
    private rollback;
    private deactivateNow;
    private deactivationIsCurrent;
    private cancelDeactivation;
    private fail;
    private update;
}
