/**
 * Pure derivation helpers of the workbench: every piece of overview/status-bar
 * data is computed here from structural inputs so the behavior is unit-testable
 * without a DOM or a runtime. The client controller only assembles the inputs.
 * @module dsh-workbench/core/derive
 */
import type { AgentSessionRow, GitSummary, GoalSummary, JobRow, RecentToolRow, SessionStatus, TokenUsageSummary, TodoSummary } from './types.ts';
/** Project display name: the last non-empty path segment (both separators). */
export declare function projectNameOf(cwd: string): string;
/** Reduce the official session list to recent Agent context rows. */
export declare function agentSessionRowsOf(rows: readonly {
    id: string;
    cwd?: unknown;
    title?: unknown;
    displayTitle?: unknown;
    running: boolean;
    pendingInteraction?: unknown;
}[], currentId: string | undefined, root: string, limit?: number): AgentSessionRow[];
/** Validate and detach the optional liveTokenUsage projection. */
export declare function tokenUsageSummaryOf(value: unknown): TokenUsageSummary | undefined;
/** Coarse run status of one session list row. */
export declare function sessionStatusOf(row: {
    running: boolean;
    pendingInteraction?: unknown;
}): SessionStatus;
/** Structural shape of one conversation node the tool extraction reads. */
export interface ToolNodeLike {
    kind: string;
    time?: number;
    callId?: string;
    call?: {
        name: string;
        argsRaw: string;
    } | null;
    isError?: boolean;
}
/** Structural shape of one running tool call. */
export interface RunningCallLike {
    name: string;
    time: number;
}
/**
 * The newest-first recent tool call rows: running calls first (live at the
 * top), then the newest in-window tool results. Unknown names degrade to the
 * callId tail; the list is capped at `limit`.
 */
export declare function extractRecentTools(nodes: readonly ToolNodeLike[], runningCalls: readonly RunningCallLike[], limit: number): RecentToolRow[];
/** Reduce the complete `todos` projection to progress. */
export declare function todoSummaryOf(value: unknown, nextCap?: number): TodoSummary | undefined;
/**
 * Reduce the host `goal` projection value to a summary. undefined = the value
 * is not a goal projection (caller shows unavailable); null = no goal set.
 */
export declare function summarizeGoal(value: unknown): GoalSummary | null | undefined;
/** Structural shape of the Workbench read-only git-status payload. */
export interface GitStatusLike {
    branch: string;
    staged: readonly unknown[];
    unstaged: readonly unknown[];
    untracked: readonly unknown[];
}
/** Reduce one git-status payload to the compact summary (null = not a repo). */
export declare function gitSummaryOf(status: GitStatusLike | null | undefined): GitSummary | null;
/** Structural subset of one direct-child catalog entry. */
export type SubagentEntryLike = {
    kind: 'child';
    id: string;
    activity: 'running' | 'inactive';
    label?: string;
} | {
    kind: 'diagnostic';
    id: string;
    reason: string;
};
/** Direct subagent rows from the durable catalog, including diagnostics. */
export declare function subagentRowsOf(entries: readonly SubagentEntryLike[] | undefined): {
    id: string;
    title: string;
    running: boolean;
}[];
/** Structural shape of one wire job row. */
export interface JobLike {
    id: string;
    kind: string;
    label: string;
    status: string;
    detail?: string;
}
/** Copy wire jobs into display rows (live jobs first, then newest started). */
export declare function jobRowsOf(jobs: readonly JobLike[] | undefined): JobRow[];
/** The workbench chat floor: phase 1 raises the panel system's 360px floor. */
export declare const CHAT_FLOOR_PX = 480;
/** Input geometry of one width-policy evaluation (all px, non-negative). */
export interface WidthGeometry {
    /** Full width of the frame grid row. */
    frameWidth: number;
    /** Shell sidebar track width (0 when not yet mirrored). */
    sidebarPx: number;
    /** Shell details track width (0 when collapsed/absent). */
    detailsPx: number;
    /** Current preview region track width (0 when closed). */
    previewPx: number;
    /** Current explorer column track width (0 when collapsed). */
    explorerPx: number;
    /** Smallest width the preview region may keep while open. */
    minPreviewPx: number;
    /** Smallest width the explorer column may keep while open. */
    minExplorerPx: number;
}
/** The corrected panel widths, or null when no correction is needed/possible. */
export interface WidthCorrection {
    previewPx: number;
    explorerPx: number;
}
/**
 * Enforce the raised chat floor against the live grid geometry. The preview
 * region yields first (it is on-demand), then the explorer. Returns null when
 * chat already meets the floor, when nothing is open, or when the container
 * is too narrow to satisfy the floor without violating the panels' own
 * minimums ("where feasible" — the guard yields instead of fighting).
 */
export declare function correctPanelWidths(geometry: WidthGeometry, chatFloor?: number): WidthCorrection | null;
