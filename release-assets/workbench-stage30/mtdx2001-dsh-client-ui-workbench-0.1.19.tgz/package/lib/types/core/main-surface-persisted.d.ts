export interface MainSurfacePersistedState {
    readonly version: 1;
    readonly activeId: string;
    readonly defaultId: string;
    readonly restoreLast: boolean;
}
export declare const AGENT_MAIN_SURFACE_ID = "agent";
export declare const DEFAULT_MAIN_SURFACE_STATE: MainSurfacePersistedState;
export declare function isMainSurfaceId(value: unknown): value is string;
export declare function parseMainSurfaceState(value: unknown): MainSurfacePersistedState | undefined;
export declare function parseMainSurfaceStateJson(raw: string | null): MainSurfacePersistedState | undefined;
