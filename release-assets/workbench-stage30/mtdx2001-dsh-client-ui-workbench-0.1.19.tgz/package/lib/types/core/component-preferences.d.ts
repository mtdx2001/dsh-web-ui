import type { AdmittedSidebarRowRegistration, SidebarRowRegistrySnapshot } from './row-registry.ts';
export type ComponentRegion = 'main-surface' | 'left-top' | 'left-bottom' | 'right-sidebar';
export interface ComponentDescriptor {
    readonly id: string;
    readonly region: ComponentRegion;
    readonly label: string;
    readonly source: string;
    readonly order: number;
    readonly defaultEnabled: boolean;
    readonly removable: boolean;
    readonly builtin: boolean;
}
export interface ComponentPreference {
    readonly enabled?: boolean;
    readonly position?: number;
    readonly removed?: boolean;
}
export interface ComponentPreferencesState {
    readonly version: 1;
    readonly components: Readonly<Record<string, ComponentPreference>>;
}
export interface EffectiveComponent extends ComponentDescriptor {
    readonly enabled: boolean;
    readonly effectivePosition: number;
    readonly removed: boolean;
}
export interface EffectiveComponentSnapshot {
    readonly revision: number;
    readonly components: readonly EffectiveComponent[];
}
export declare function descriptorsFromSidebar(snapshot: SidebarRowRegistrySnapshot, getRow?: (id: string) => AdmittedSidebarRowRegistration | undefined): ComponentDescriptor[];
export interface DockComponentRegistration {
    readonly id: string;
    readonly order: number;
    readonly label: string | (() => string);
    readonly source?: string;
    readonly kind?: 'builtin' | 'extension';
    readonly defaultEnabled?: boolean;
    readonly removable?: boolean;
}
export declare function descriptorsFromDock(tabs: readonly DockComponentRegistration[]): ComponentDescriptor[];
export declare const COMPONENT_PREFERENCES_KEY = "dsh-workbench-component-preferences:v1:global";
export declare function componentPreferencesKey(root: string): string;
export declare function parseComponentPreferences(raw: string | null): ComponentPreferencesState;
export declare function deriveEffectiveComponents(descriptors: readonly ComponentDescriptor[], state: ComponentPreferencesState): EffectiveComponent[];
export declare class ComponentPreferencesService {
    private readonly storage;
    private state;
    private root;
    private readonly collections;
    private descriptors;
    private snapshot;
    private readonly listeners;
    constructor(storage?: Pick<Storage, 'getItem' | 'setItem'> | undefined);
    getSnapshot: () => EffectiveComponentSnapshot;
    subscribe: (listener: () => void) => (() => void);
    /** Switch the layout preference layer with the active project root. */
    setRoot(root: string): void;
    /** Compatibility entry point for callers that own the complete descriptor list. */
    reconcile(descriptors: readonly ComponentDescriptor[]): void;
    /** Reconcile one independently owned descriptor collection without dropping others. */
    reconcileCollection(owner: string, descriptors: readonly ComponentDescriptor[]): void;
    setEnabled(id: string, enabled: boolean): void;
    setPosition(id: string, region: ComponentRegion, value: number): void;
    move(id: string, direction: -1 | 1): void;
    setRemoved(id: string, removed: boolean): void;
    reset(id?: string): void;
    private has;
    private patch;
    private publish;
    private persist;
}
