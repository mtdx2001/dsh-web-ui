import { type MainSurfacePersistedState } from './main-surface-persisted.ts';
export interface MainSurfaceStateSnapshot {
    readonly revision: number;
    readonly activeId: string;
    readonly defaultId: string;
    readonly restoreLast: boolean;
}
export declare const MAIN_SURFACE_STATE_KEY = "dsh-workbench-main-surface:v1:global";
export type MainSurfaceStateWriter = (value: MainSurfacePersistedState) => void | Promise<void>;
export declare class MainSurfaceStateService {
    private readonly storage;
    private readonly listeners;
    private state;
    private snapshot;
    private writer;
    private writeQueue;
    constructor(storage?: Pick<Storage, 'getItem' | 'setItem'> | undefined);
    getSnapshot: () => MainSurfaceStateSnapshot;
    subscribe: (listener: () => void) => (() => void);
    setWriter(writer: MainSurfaceStateWriter | undefined): void;
    hydrate(value: MainSurfacePersistedState): void;
    activate(id: string): void;
    setDefault(id: string): void;
    setRestoreLast(restoreLast: boolean): void;
    reset(): void;
    private sameState;
    private publish;
    private emit;
}
