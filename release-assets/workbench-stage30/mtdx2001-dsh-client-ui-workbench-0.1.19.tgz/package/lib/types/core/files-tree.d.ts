/**
 * Pure directory-tree helpers for the Workbench Files tab: shared between the
 * browser panel and tests, free of DOM, fetch, and fs.
 * @module dsh-workbench/core/files-tree
 */
export interface FileTreeNode {
    readonly name: string;
    /** Workspace-relative path using `/` separators. */
    readonly path: string;
    readonly kind: 'file' | 'directory';
    readonly children?: readonly FileTreeNode[];
}
/** Git status letters shown on file rows. */
export type FileStatusState = 'modified' | 'created' | 'deleted' | 'untracked';
export declare const FILE_STATUS_BADGE: Record<FileStatusState, string>;
/**
 * Keep only nodes whose own name matches `query` (case-insensitive) or that
 * have a matching descendant. Directories keep their filtered children so the
 * path to each match stays visible.
 */
export declare function filterFileTree(nodes: readonly FileTreeNode[], query: string): FileTreeNode[];
/** Convert a git-status route payload into a workspace-relative path → state map. */
export declare function fileStatusMapOf(value: {
    staged?: readonly {
        path: string;
        state: string;
    }[];
    unstaged?: readonly {
        path: string;
        state: string;
    }[];
    untracked?: readonly {
        path: string;
        state: string;
    }[];
} | null | undefined): Map<string, FileStatusState>;
