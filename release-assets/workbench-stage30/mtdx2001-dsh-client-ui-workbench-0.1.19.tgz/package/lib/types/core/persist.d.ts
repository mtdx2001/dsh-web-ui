/**
 * Per-project UI persistence: one JSON record per project root in
 * localStorage (`dsh-workbench-ui:<root>`), range-validated on read so a
 * broken or hand-edited value falls back to defaults instead of corrupting
 * the layout. Writes are idempotent (same-value writes are skipped).
 * @module dsh-workbench/core/persist
 */
import { type WorkbenchUiState } from './types.ts';
/** Storage key prefix for the per-project UI record. */
export declare const KEY_UI_PREFIX = "dsh-workbench-ui:";
/** Parse a stored JSON value; fallback on any failure. */
export declare function readJson<T>(key: string, fallback: T): T;
/** Serialize a JSON value (quota failures degrade silently). */
export declare function writeJson(key: string, value: unknown): boolean;
/** Read one project's UI state (defaults when absent or invalid). */
export declare function readUiState(root: string): WorkbenchUiState;
/** Write one project's UI state (no-op for the empty root). */
export declare function writeUiState(root: string, state: WorkbenchUiState): void;
