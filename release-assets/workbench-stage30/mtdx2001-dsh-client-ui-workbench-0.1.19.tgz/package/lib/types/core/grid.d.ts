/**
 * Grid-template-columns parsing helpers (pure string math, shared by the
 * width guard and its tests). Mirrors the panel system's parser contract:
 * tracks split on top-level spaces only, so "minmax(0, 1fr)" stays whole.
 * @module dsh-workbench/core/grid
 */
/** Parse an inline grid-template-columns string into its tracks ('' on failure). */
export declare function parseGridTracks(input: string): string[];
/** Extract a px width from one track (0 for fr/minmax/non-px tracks). */
export declare function trackPx(track: string): number;
/** Render the five-track grid the panel system owns (sidebar, center, details, preview, explorer). */
export declare function renderFiveTracks(sidebar: string, details: string, previewPx: number, explorerPx: number): string;
