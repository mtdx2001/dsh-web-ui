import type { ReactNode } from 'react';
export type SidebarRowSlot = 'top' | 'bottom';
export type SidebarRowKind = 'action' | 'disclosure' | 'toggle';
export type SidebarRowMetadataValue = string | number | boolean | null | readonly SidebarRowMetadataValue[] | {
    readonly [key: string]: SidebarRowMetadataValue;
};
export type SidebarRowMetadata = Readonly<Record<string, SidebarRowMetadataValue>>;
interface SidebarRowBase {
    readonly id: string;
    readonly slot: SidebarRowSlot;
    readonly order: number;
    readonly label: string | (() => string);
    readonly source: string;
    readonly metadata?: SidebarRowMetadata;
    readonly builtin?: boolean;
    readonly removable?: boolean;
    readonly icon?: () => ReactNode;
    readonly summary?: () => ReactNode;
    readonly onHostPresenceChange?: (present: boolean) => void;
}
export interface SidebarActionRowRegistration extends SidebarRowBase {
    readonly kind: 'action';
    readonly onAction: () => void | Promise<void>;
    readonly active?: () => boolean;
}
export interface SidebarDisclosureRowRegistration extends SidebarRowBase {
    readonly kind: 'disclosure';
    readonly details: () => ReactNode;
    readonly expanded: () => boolean;
    readonly onToggle: () => void | Promise<void>;
}
export interface SidebarToggleRowRegistration extends SidebarRowBase {
    readonly kind: 'toggle';
    readonly checked: () => boolean;
    readonly onChange: (checked: boolean) => void | Promise<void>;
}
/** Compatibility shape accepted from row contributors released before interaction kinds. */
export interface LegacySidebarRowRegistration {
    readonly id: string;
    readonly slot: SidebarRowSlot;
    readonly order: number;
    readonly label: string | (() => string);
    readonly source?: string;
    readonly metadata?: SidebarRowMetadata;
    readonly builtin?: boolean;
    readonly removable?: boolean;
    readonly icon?: () => ReactNode;
    readonly summary?: () => ReactNode;
    readonly details?: () => ReactNode;
    readonly expanded?: () => boolean;
    readonly onHostPresenceChange?: (present: boolean) => void;
    readonly toggle: () => void | Promise<void>;
}
export type SidebarRowRegistration = SidebarActionRowRegistration | SidebarDisclosureRowRegistration | SidebarToggleRowRegistration | LegacySidebarRowRegistration;
export interface AdmittedSidebarRowRegistration {
    readonly id: string;
    readonly componentId: string;
    readonly source: string;
    readonly slot: SidebarRowSlot;
    readonly order: number;
    readonly registrationIndex: number;
    readonly label: string;
    readonly resolveLabel: () => string;
    readonly kind: SidebarRowKind;
    readonly metadata: SidebarRowMetadata;
    readonly builtin: boolean;
    readonly removable: boolean;
    readonly icon?: () => ReactNode;
    readonly summary?: () => ReactNode;
    readonly details?: () => ReactNode;
    readonly active: () => boolean;
    readonly expanded: () => boolean;
    readonly checked: () => boolean;
    readonly invoke: () => void | Promise<void>;
    readonly onHostPresenceChange?: (present: boolean) => void;
}
export interface SidebarRowSummary {
    readonly id: string;
    readonly componentId: string;
    readonly source: string;
    readonly slot: SidebarRowSlot;
    readonly order: number;
    readonly registrationIndex: number;
    readonly label: string;
    readonly kind: SidebarRowKind;
    readonly active: boolean;
    readonly expanded: boolean;
    readonly checked: boolean;
}
export interface SidebarRowRegistrySnapshot {
    readonly revision: number;
    readonly rows: readonly SidebarRowSummary[];
}
export type SidebarRowAdmissionCode = 'invalid_registration' | 'invalid_id' | 'invalid_source' | 'invalid_slot' | 'invalid_label' | 'invalid_order' | 'invalid_metadata' | 'sensitive_metadata' | 'missing_callback' | 'duplicate_id';
export interface SidebarRowAdmissionDiagnostic {
    readonly code: SidebarRowAdmissionCode;
    readonly message: string;
    readonly id?: string;
    readonly field?: string;
}
export type SidebarRowAdmissionResult = {
    readonly ok: true;
    readonly registration: AdmittedSidebarRowRegistration;
    readonly dispose: () => void;
} | {
    readonly ok: false;
    readonly diagnostic: SidebarRowAdmissionDiagnostic;
};
export declare class SidebarRowAdmissionError extends TypeError {
    readonly diagnostic: SidebarRowAdmissionDiagnostic;
    constructor(diagnostic: SidebarRowAdmissionDiagnostic);
}
export declare class SidebarRowRegistry {
    private readonly registrations;
    private readonly listeners;
    private nextRegistrationIndex;
    private snapshot;
    getSnapshot: () => SidebarRowRegistrySnapshot;
    subscribe: (listener: () => void) => (() => void);
    admit(registration: SidebarRowRegistration): SidebarRowAdmissionResult;
    register(registration: SidebarRowRegistration): () => void;
    get(id: string): AdmittedSidebarRowRegistration | undefined;
    refresh(id?: string): void;
    clear(): void;
    private rebuild;
}
export {};
