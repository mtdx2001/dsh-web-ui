export type NavigationLayoutMode = 'wide' | 'compact' | 'drawer' | 'mobile';
export interface NavigationLayout {
    readonly mode: NavigationLayoutMode;
    readonly railSize: number;
    readonly contextWidth: number;
    readonly contextOverlay: boolean;
}
/** Stable breakpoint policy for the shell-overlay navigation surface. */
export declare function navigationLayoutFor(viewportWidth: number): NavigationLayout;
