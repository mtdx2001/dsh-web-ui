/**
 * Framework-free state primitive of the workbench (the same minimal
 * subscribe/getSnapshot shape the sibling panel packages use), plus the
 * workbench store bundle: the live overview snapshot and the per-project UI
 * state. All reducers are pure; async work lives in the client controller.
 * @module dsh-workbench/core/store
 */
import { type OverviewSnapshot, type WorkbenchUiState } from './types.ts';
/** A minimal external store usable with useSyncExternalStore. */
export interface StateHandle<S> {
    getSnapshot: () => S;
    subscribe: (listener: () => void) => () => void;
    /** Pure update: fn receives the previous state and returns the next. */
    update: (fn: (prev: S) => S) => void;
}
/** Create a state handle with an immutable snapshot (new object per update). */
export declare function createState<S>(initial: S): StateHandle<S>;
/** The workbench store bundle shared by the status bar and the overview. */
export interface WorkbenchStores {
    /** Live overview data (project, session, goal, todos, jobs, ...). */
    overview: StateHandle<OverviewSnapshot>;
    /** Per-project UI state (persisted; reloaded on project switch). */
    ui: StateHandle<WorkbenchUiState>;
    /** Toggle the compatibility Overview marker; persists against the current project root. */
    setOverviewActive: (active: boolean) => void;
    /** Persist the active Workbench-owned right-sidebar component. */
    setActiveRightPanel: (id: string) => void;
}
/** Create the store bundle (UI state loads lazily per project root). */
export declare function createWorkbenchStores(): WorkbenchStores;
/**
 * Rebind the UI store to another project root: the persisted state of the new
 * root loads (defaults when absent or invalid).
 */
export declare function uiSetRoot(stores: WorkbenchStores, root: string): void;
