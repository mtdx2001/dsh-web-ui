import type { ISessions } from '@deepseek-ai/dsh-client-runtime/client';
import type { WorkbenchStores } from '../core/store.ts';
import type { WorkbenchServiceFace } from './workbench-service.ts';
/** Register independently disposable built-in rows into the shared top stack. */
export declare function registerBuiltinSidebarRows(service: WorkbenchServiceFace, stores: WorkbenchStores, sessions: ISessions): () => void;
