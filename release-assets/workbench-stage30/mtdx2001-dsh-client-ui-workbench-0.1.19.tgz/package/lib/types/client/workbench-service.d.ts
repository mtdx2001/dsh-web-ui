import type { Context } from '@deepseek-ai/cordis';
import { type ModuleRegistrySnapshot, type WorkbenchModuleRegistration } from '../core/module-registry.ts';
import { type NavigationResult, type NavigationSnapshot } from '../core/navigation-state.ts';
import { type AdmittedSidebarRowRegistration, type SidebarRowAdmissionResult, type SidebarRowRegistration, type SidebarRowRegistrySnapshot } from '../core/row-registry.ts';
import { ComponentPreferencesService } from '../core/component-preferences.ts';
import { type WorkbenchRightPanelRegistration, type WorkbenchRightPanelSnapshot } from '../core/right-panel-registry.ts';
import { type MainSurfaceRegistrySnapshot, type WorkbenchMainSurfaceRegistration } from '../core/main-surface-registry.ts';
import { MainSurfaceStateService } from '../core/main-surface-state.ts';
export type WorkbenchModuleDisposer = () => void | Promise<void>;
export interface WorkbenchServiceFace {
    register(module: WorkbenchModuleRegistration): WorkbenchModuleDisposer;
    registerSidebarRow(row: SidebarRowRegistration): WorkbenchModuleDisposer;
    admitSidebarRow(row: SidebarRowRegistration): SidebarRowAdmissionResult;
    refreshSidebarRow(rowId?: string): void;
    getSidebarRows(): SidebarRowRegistrySnapshot;
    getSidebarRow(rowId: string): AdmittedSidebarRowRegistration | undefined;
    subscribeSidebarRows(listener: () => void): () => void;
    registerRightPanel(panel: WorkbenchRightPanelRegistration): WorkbenchModuleDisposer;
    refreshRightPanel(panelId?: string): void;
    getRightPanels(): WorkbenchRightPanelSnapshot;
    getRightPanel(panelId: string): WorkbenchRightPanelRegistration | undefined;
    subscribeRightPanels(listener: () => void): () => void;
    registerMainSurface(mode: WorkbenchMainSurfaceRegistration): WorkbenchModuleDisposer;
    refreshMainSurface(modeId?: string): void;
    getMainSurfaces(): MainSurfaceRegistrySnapshot;
    getMainSurface(modeId: string): WorkbenchMainSurfaceRegistration | undefined;
    subscribeMainSurfaces(listener: () => void): () => void;
    getMainSurfaceState(): MainSurfaceStateService;
    getComponentPreferences(): ComponentPreferencesService;
    refresh(moduleId?: string): void;
    getModules(): ModuleRegistrySnapshot;
    subscribeModules(listener: () => void): () => void;
    activate(moduleId: string): Promise<NavigationResult>;
    /** Synchronize state already changed by a legacy host entry. */
    adopt(moduleId: string | undefined): Promise<NavigationResult>;
    deactivate(): Promise<NavigationResult>;
    getNavigation(): NavigationSnapshot;
    subscribeNavigation(listener: () => void): () => void;
}
export declare class WorkbenchService implements WorkbenchServiceFace {
    private readonly registry;
    private readonly rows;
    private readonly rightPanels;
    private readonly mainSurfaces;
    private readonly mainSurfaceState;
    private readonly navigation;
    private readonly componentPreferences;
    private disposal;
    private disposed;
    constructor(componentPreferences?: ComponentPreferencesService);
    getComponentPreferences(): ComponentPreferencesService;
    getMainSurfaceState(): MainSurfaceStateService;
    private syncSidebarComponents;
    private syncMainSurfaceComponents;
    private syncRightPanelComponents;
    register(module: WorkbenchModuleRegistration): WorkbenchModuleDisposer;
    registerSidebarRow(row: SidebarRowRegistration): WorkbenchModuleDisposer;
    admitSidebarRow(row: SidebarRowRegistration): SidebarRowAdmissionResult;
    refreshSidebarRow(rowId?: string): void;
    getSidebarRows(): SidebarRowRegistrySnapshot;
    getSidebarRow(rowId: string): AdmittedSidebarRowRegistration | undefined;
    subscribeSidebarRows(listener: () => void): () => void;
    registerRightPanel(panel: WorkbenchRightPanelRegistration): WorkbenchModuleDisposer;
    refreshRightPanel(panelId?: string): void;
    getRightPanels(): WorkbenchRightPanelSnapshot;
    getRightPanel(panelId: string): WorkbenchRightPanelRegistration | undefined;
    subscribeRightPanels(listener: () => void): () => void;
    registerMainSurface(mode: WorkbenchMainSurfaceRegistration): WorkbenchModuleDisposer;
    refreshMainSurface(modeId?: string): void;
    getMainSurfaces(): MainSurfaceRegistrySnapshot;
    getMainSurface(modeId: string): WorkbenchMainSurfaceRegistration | undefined;
    subscribeMainSurfaces(listener: () => void): () => void;
    refresh(moduleId?: string): void;
    getModules(): ModuleRegistrySnapshot;
    subscribeModules(listener: () => void): () => void;
    activate(moduleId: string): Promise<NavigationResult>;
    adopt(moduleId: string | undefined): Promise<NavigationResult>;
    deactivate(): Promise<NavigationResult>;
    getNavigation(): NavigationSnapshot;
    subscribeNavigation(listener: () => void): () => void;
    dispose(): Promise<void>;
}
/** Provide the optional registry face for workbench-aware client plugins. */
export declare function provideWorkbenchService(ctx: Context): WorkbenchService;
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Optional module and right-sidebar registry for workbench-aware client plugins. */
        workbench: WorkbenchServiceFace;
    }
}
