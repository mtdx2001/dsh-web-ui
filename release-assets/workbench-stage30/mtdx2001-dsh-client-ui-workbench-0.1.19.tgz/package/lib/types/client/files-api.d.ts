/**
 * Browser-side client for the package-owned read-only files and git-status
 * routes. Injectable so the panel and tests never touch fetch directly.
 * @module dsh-workbench/client/files-api
 */
export interface FilesApiListResult {
    readonly entries: readonly {
        name: string;
        kind: 'file' | 'directory';
    }[];
    readonly truncated: boolean;
}
export interface FilesApiReadResult {
    readonly kind: 'text';
    readonly content: string;
}
export interface GitStatusPayload {
    readonly staged: readonly {
        path: string;
        state: string;
    }[];
    readonly unstaged: readonly {
        path: string;
        state: string;
    }[];
    readonly untracked: readonly {
        path: string;
        state: string;
    }[];
}
export type FilesApiOutcome<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error: string;
};
export interface FilesApi {
    list(root: string, rel: string, signal?: AbortSignal): Promise<FilesApiOutcome<FilesApiListResult>>;
    read(root: string, rel: string, signal?: AbortSignal): Promise<FilesApiOutcome<FilesApiReadResult>>;
    gitStatus(root: string, signal?: AbortSignal): Promise<GitStatusPayload | null>;
}
type FetchLike = (input: string, init?: {
    method?: string;
    headers?: Record<string, string>;
    body?: string;
    signal?: AbortSignal;
}) => Promise<{
    ok: boolean;
    json: () => Promise<unknown>;
}>;
/** Create the default fetch-backed API client. */
export declare function createFilesApi(fetchImpl?: FetchLike): FilesApi;
export {};
