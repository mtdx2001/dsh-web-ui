/**
 * Browser-side client for the package-owned git-status and git-changes
 * routes. Injectable so the panel and tests never touch fetch directly.
 * Responses are structurally validated and bounded before use.
 * @module dsh-workbench/client/changes-api
 */
export interface ChangeRow {
    readonly path: string;
    readonly state: string;
}
export interface ChangesStatusPayload {
    readonly root: string;
    readonly branch: string;
    readonly staged: readonly ChangeRow[];
    readonly unstaged: readonly ChangeRow[];
    readonly untracked: readonly ChangeRow[];
}
export interface ChangesDiffResult {
    readonly content: string;
    readonly truncated: boolean;
}
export type ChangesApiOutcome<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error: string;
};
export interface ChangesApi {
    /** null means the admitted workspace is not a Git repository; undefined means the request failed. */
    status(root: string, signal?: AbortSignal): Promise<ChangesStatusPayload | null | undefined>;
    diff(root: string, path: string, signal?: AbortSignal): Promise<ChangesApiOutcome<ChangesDiffResult>>;
    stage(root: string, path: string, signal?: AbortSignal): Promise<ChangesApiOutcome<Record<string, never>>>;
    unstage(root: string, path: string, signal?: AbortSignal): Promise<ChangesApiOutcome<Record<string, never>>>;
    discard(root: string, path: string, signal?: AbortSignal): Promise<ChangesApiOutcome<Record<string, never>>>;
}
type FetchLike = (input: string, init?: {
    method?: string;
    headers?: Record<string, string>;
    body?: string;
    signal?: AbortSignal;
}) => Promise<{
    ok: boolean;
    json: () => Promise<unknown>;
}>;
/** Validate and bound one status payload; returns null on any shape violation. */
export declare function sanitizeStatus(value: unknown): ChangesStatusPayload | null;
/** Create the default fetch-backed API client. */
export declare function createChangesApi(fetchImpl?: FetchLike): ChangesApi;
export {};
