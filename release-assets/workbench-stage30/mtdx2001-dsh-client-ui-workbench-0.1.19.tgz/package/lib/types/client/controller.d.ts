/** Runtime controller for the Phase 1 overview snapshot. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type WorkbenchStores } from '../core/store.ts';
import type { ComponentPreferencesService } from '../core/component-preferences.ts';
/** Bind framework-free stores to official runtime snapshots and projections. */
export declare function startController(ctx: ClientContext, stores: WorkbenchStores, componentPreferences?: ComponentPreferencesService): () => void;
