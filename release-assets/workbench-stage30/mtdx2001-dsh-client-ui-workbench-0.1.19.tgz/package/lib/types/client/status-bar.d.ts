import type { JSX } from 'react';
import type { WorkbenchStores } from '../core/store.ts';
/** Additive Session Header utility; the official owner mounts and disposes it. */
export declare function StatusBar({ stores, openRightSidebar }: {
    stores: WorkbenchStores;
    openRightSidebar?: () => void;
}): JSX.Element;
