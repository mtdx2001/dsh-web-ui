/**
 * Workbench Changes tab: staged / unstaged / untracked groups over the
 * package-owned git-status route, with per-row write actions through the
 * policy-enforcing git-changes route. Clicking a file shows a bounded unified
 * diff inside the same content area with a back button. Every successful
 * write re-reads the host status; there are no optimistic list updates.
 * Discard and untracked delete require explicit confirmation. Conflict rows
 * render without write buttons. No bulk discard anywhere.
 * @module dsh-workbench/client/ChangesPanel
 */
import { type JSX } from 'react';
import type { WorkbenchStores } from '../core/store.ts';
import { type ChangesApi } from './changes-api.ts';
export interface ChangesPanelProps {
    readonly stores: WorkbenchStores;
    /** Injectable for tests; defaults to the fetch-backed client. */
    readonly api?: ChangesApi;
}
export declare function ChangesPanel({ stores, api }: ChangesPanelProps): JSX.Element;
