export interface NewsSource {
    id: string;
    label: string;
}
export interface NewsItem {
    title: string;
    summary: string;
    link?: string;
    published?: string;
}
export declare function parseNewsFeed(content: string): NewsItem[];
export declare function listNewsSources(signal: AbortSignal): Promise<NewsSource[]>;
export declare function loadNewsSource(id: string, signal: AbortSignal): Promise<NewsItem[]>;
