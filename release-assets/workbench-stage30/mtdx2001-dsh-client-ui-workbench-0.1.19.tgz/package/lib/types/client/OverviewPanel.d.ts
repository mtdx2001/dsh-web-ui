/**
 * The Overview tab content: compact flat sections (project, session, goal,
 * todos, background jobs, subagents, recent tools, git) with explicit
 * unavailable states. No nested cards, no decoration — grouped rows separated
 * by hairlines, per the workbench phase-1 spec.
 * @module dsh-workbench/client/OverviewPanel
 */
import type { JSX } from 'react';
import type { WorkbenchStores } from '../core/store.ts';
/** The overview panel body. */
export declare function OverviewPanel({ stores }: {
    stores: WorkbenchStores;
}): JSX.Element;
