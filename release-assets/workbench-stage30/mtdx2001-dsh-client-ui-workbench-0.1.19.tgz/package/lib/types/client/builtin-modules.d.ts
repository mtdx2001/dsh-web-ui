import type { WorkbenchModuleRegistration } from '../core/module-registry.ts';
import type { WorkbenchServiceFace } from './workbench-service.ts';
export declare function builtinModuleRegistrations(doc?: Document): WorkbenchModuleRegistration[];
/** Register built-ins and mirror the retained Settings entry into navigation state. */
export declare function registerBuiltinModules(service: WorkbenchServiceFace, doc?: Document): () => Promise<void>;
