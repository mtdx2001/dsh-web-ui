import type { CustomComponentService } from '../core/custom-components.ts';
import type { WorkbenchServiceFace } from './workbench-service.ts';
type Dispose = () => void | Promise<void>;
/** Project persisted structured definitions through the existing public registries. */
export declare function registerCustomComponents(service: WorkbenchServiceFace, custom: CustomComponentService): Dispose;
export {};
