/** Defer optional runtime and geometry work until the shell has painted twice. */
export declare function afterFirstPaint(task: () => void): () => void;
