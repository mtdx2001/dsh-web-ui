import { type JSX } from 'react';
import type { ISessions } from '@deepseek-ai/dsh-client-runtime/client';
import type { WorkbenchStores } from '../core/store.ts';
import type { WorkbenchServiceFace } from './workbench-service.ts';
export interface WorkbenchOverlayProps {
    service: WorkbenchServiceFace;
    stores: WorkbenchStores;
    sessions: ISessions;
}
export declare function WorkbenchOverlay({ service, stores, sessions }: WorkbenchOverlayProps): JSX.Element;
