/**
 * Workbench browser half. Status and module navigation contribute through
 * official slots. Runtime reads, optional contributions, and observers start only
 * after the shell has painted; dormant Overview DOM integration stays disabled.
 * @module dsh-workbench/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type SidebarRowsOwnerProps } from './SidebarRows.tsx';
import { type WorkbenchRightPanelOwnerProps } from './WorkbenchRightPanelHost.tsx';
import { type WorkbenchMainSurfaceOwnerProps } from './WorkbenchMainSurfaceHost.tsx';
import { type WorkbenchKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Workbench surface copy. */
        'workbench': WorkbenchKey;
    }
    interface SlotMap {
        /** Official ui-layout additive frame overlay seat. */
        'shell.overlay': {
            kind: 'list';
            scope: 'root';
        };
        /** Optional future Sidebar-owned row stack after New Session. */
        'sidebar.rows.top': {
            kind: 'list';
            scope: 'root';
            owner: SidebarRowsOwnerProps;
        };
        /** Optional future Sidebar-owned row stack before Settings. */
        'sidebar.rows.bottom': {
            kind: 'list';
            scope: 'root';
            owner: SidebarRowsOwnerProps;
        };
        /** Optional official settings section for component management. */
        'settings.section': {
            kind: 'list';
            scope: 'root';
        };
        /** Optional Conversation-owned central main-surface host. */
        'conversation.mainSurface': {
            kind: 'single';
            scope: 'session-maybe';
            owner: WorkbenchMainSurfaceOwnerProps;
        };
        /** Optional Desktop-owned right-sidebar host. */
        'desktop.rightSidebar': {
            kind: 'single';
            scope: 'session-maybe';
            owner: WorkbenchRightPanelOwnerProps & {
                details: import('react').ReactNode;
                detailsRequestRevision: number;
                close: () => void;
            };
        };
    }
}
/** Required services: official runtime projections, slots, and locale. */
export declare const inject: string[];
export { afterFirstPaint } from './after-first-paint.ts';
/** Apply the browser half. */
export declare function apply(ctx: ClientContext): void;
