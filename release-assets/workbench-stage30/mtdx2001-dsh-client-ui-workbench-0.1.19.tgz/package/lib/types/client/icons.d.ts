/**
 * Lucide-compatible stroke icons (24x24 viewBox, currentColor, 1.5 stroke) —
 * the same restrained inline-SVG pattern the sibling panel packages use.
 * @module dsh-workbench/client/icons
 */
import type { JSX } from 'react';
interface IconProps {
    size?: number;
}
/** Folder glyph (project section). */
export declare function FolderIcon({ size }: IconProps): JSX.Element;
/** Message glyph (session section). */
export declare function MessageIcon({ size }: IconProps): JSX.Element;
/** Target glyph (goal section). */
export declare function TargetIcon({ size }: IconProps): JSX.Element;
/** List-checks glyph (todo section). */
export declare function ListChecksIcon({ size }: IconProps): JSX.Element;
/** Clock glyph (background jobs section). */
export declare function ClockIcon({ size }: IconProps): JSX.Element;
/** Branch glyph (subagents + git sections). */
export declare function BranchIcon({ size }: IconProps): JSX.Element;
/** Wrench glyph (recent tools section). */
export declare function WrenchIcon({ size }: IconProps): JSX.Element;
export declare function AgentIcon({ size }: IconProps): JSX.Element;
export declare function TasksIcon({ size }: IconProps): JSX.Element;
export declare function SshIcon({ size }: IconProps): JSX.Element;
export declare function KnowledgeIcon({ size }: IconProps): JSX.Element;
export declare function ExpertsIcon({ size }: IconProps): JSX.Element;
export declare function NewsIcon({ size }: IconProps): JSX.Element;
export declare function MonitoringIcon({ size }: IconProps): JSX.Element;
export declare function SettingsIcon({ size }: IconProps): JSX.Element;
export declare function CloseIcon({ size }: IconProps): JSX.Element;
export declare function OverviewIcon({ size }: IconProps): JSX.Element;
export declare function DetailsIcon({ size }: IconProps): JSX.Element;
/** File glyph (files tab rows). */
export declare function FileIcon({ size }: IconProps): JSX.Element;
/** Chevron glyphs for directory expand/collapse. */
export declare function ChevronIcon({ size, open }: IconProps & {
    open?: boolean;
}): JSX.Element;
/** Refresh glyph (files toolbar). */
export declare function RefreshIcon({ size }: IconProps): JSX.Element;
/** Collapse-all glyph (files toolbar). */
export declare function CollapseAllIcon({ size }: IconProps): JSX.Element;
/** Back arrow glyph (files preview). */
export declare function BackIcon({ size }: IconProps): JSX.Element;
/** Official Sidebar panel glyph mirrored for a right-side panel. */
export declare function RightPanelIcon({ size }: IconProps): JSX.Element;
export {};
