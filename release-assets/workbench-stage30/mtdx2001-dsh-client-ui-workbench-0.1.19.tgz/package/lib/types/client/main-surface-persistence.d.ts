import { type MainSurfacePersistedState } from '../core/main-surface-persisted.ts';
export declare function loadMainSurfaceState(signal?: AbortSignal): Promise<MainSurfacePersistedState | undefined>;
export declare function saveMainSurfaceState(value: MainSurfacePersistedState): Promise<boolean>;
