/**
 * Workbench Files tab: a single-column directory tree over the current
 * session workspace, backed by the package-owned read-only files route. The
 * toolbar holds only search, refresh, and collapse-all; clicking a file opens
 * a read-only preview inside the same content region with back + breadcrumb.
 * No editing, staging, or layout ownership.
 * @module dsh-workbench/client/FilesPanel
 */
import { type JSX } from 'react';
import type { WorkbenchStores } from '../core/store.ts';
import { type FilesApi } from './files-api.ts';
export interface FilesPanelProps {
    readonly stores: WorkbenchStores;
    /** Injectable for tests; defaults to the fetch-backed client. */
    readonly api?: FilesApi;
}
export declare function FilesPanel({ stores, api }: FilesPanelProps): JSX.Element;
