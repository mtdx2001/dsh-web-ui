/**
 * React binding for the framework-free stores: useSyncExternalStore with a
 * stable snapshot (the stores return immutable snapshots, so selector-free
 * subscription is safe).
 * @module dsh-workbench/client/hooks/useStore
 */
import type { StateHandle } from '../../core/store.ts';
/** Subscribe a component to one store (full snapshot). */
export declare function useStore<S>(store: StateHandle<S>): S;
