import { type JSX, type ReactNode } from 'react';
import type { WorkbenchStores } from '../core/store.ts';
import type { WorkbenchServiceFace } from './workbench-service.ts';
export interface WorkbenchRightPanelOwnerProps {
    readonly collapsed: boolean;
    readonly width: number;
    readonly toggle: () => void;
}
export interface WorkbenchRightPanelHostProps {
    readonly service: WorkbenchServiceFace;
    readonly stores: WorkbenchStores;
    readonly width: number;
    readonly details: ReactNode;
    readonly detailsRequestRevision: number;
    readonly close: () => void;
}
export declare function WorkbenchRightPanelHost({ service, stores, width, details, detailsRequestRevision, close }: WorkbenchRightPanelHostProps): JSX.Element;
