import { type JSX, type ReactNode } from 'react';
import type { WorkbenchServiceFace } from './workbench-service.ts';
export interface WorkbenchMainSurfaceOwnerProps {
    readonly agent: ReactNode;
}
export declare function WorkbenchMainSurfaceHost({ agent, service }: WorkbenchMainSurfaceOwnerProps & {
    service: WorkbenchServiceFace;
}): JSX.Element;
