import { type JSX } from 'react';
import { listNewsSources, loadNewsSource } from './news-feed.ts';
export interface NewsRowApi {
    readonly list: typeof listNewsSources;
    readonly load: typeof loadNewsSource;
}
/** Trusted Host-configured news sources rendered inside the bounded top sidebar row. */
export declare function NewsRow({ api }: {
    api?: NewsRowApi;
}): JSX.Element;
