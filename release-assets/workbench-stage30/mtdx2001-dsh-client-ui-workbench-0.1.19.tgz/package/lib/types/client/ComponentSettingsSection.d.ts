import { type ReactNode } from 'react';
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ComponentPreferencesService } from '../core/component-preferences.ts';
import type { MainSurfaceStateService } from '../core/main-surface-state.ts';
import type { CustomComponentService } from '../core/custom-components.ts';
type Props = PropsRuntime<'settings.section'> & PropsLocale<'workbench'> & {
    service: ComponentPreferencesService;
    mainSurface: MainSurfaceStateService;
    custom: CustomComponentService;
};
export declare function ComponentSettingsSection({ t, service, mainSurface, custom }: Props): ReactNode;
export {};
