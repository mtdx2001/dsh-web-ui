import { type ReactNode } from 'react';
import type { SidebarRowSlot } from '../core/row-registry.ts';
import type { WorkbenchServiceFace } from './workbench-service.ts';
export interface SidebarRowsOwnerProps {
    readonly wide: boolean;
}
export interface SidebarRowsProps extends SidebarRowsOwnerProps {
    readonly service: WorkbenchServiceFace;
    readonly slot: SidebarRowSlot;
}
export declare function SidebarRows({ service, slot, wide }: SidebarRowsProps): ReactNode;
